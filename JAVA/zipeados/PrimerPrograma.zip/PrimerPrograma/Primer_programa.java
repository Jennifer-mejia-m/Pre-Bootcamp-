package PrimerPrograma;
public class Primer_programa {
    public static void main(String[] args) {
        System.out.println("Mi nombre es Coding Dojo");
        System.out.println("Tengo 100 años de edad");
        System.out.println("Mi ciudad natal es Burbank, CA");
    }
}
