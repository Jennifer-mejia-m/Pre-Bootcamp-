package PUZZLES;

public class nexInt {

}
