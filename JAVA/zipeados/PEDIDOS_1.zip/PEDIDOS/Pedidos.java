package PEDIDOS;

import java.util.ArrayList;

public class Pedidos {

        public String nombre;
        public double total;
        public boolean listo;
        public ArrayList<String>items = new ArrayList<>();
    
}

