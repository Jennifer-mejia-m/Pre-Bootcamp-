package PEDIDOS;

public class Articulos {
    
    public String nombre;
    public double precio;

}
