package GuardianaZoo;

public class Mamifero {

    private int nivelEnergia=100;

    public int mostrarEnergia() {
        return nivelEnergia;
    }

    public int getNivelEnergia() {
        return nivelEnergia;
    }

    public void setNivelEnergia(int nivelEnergia) {
        this.nivelEnergia = nivelEnergia;
    }
    
}
