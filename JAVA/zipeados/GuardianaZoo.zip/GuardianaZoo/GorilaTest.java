package GuardianaZoo;

public class GorilaTest {
    
public static void main(String[] args) {
    
    Gorila Carlos = new Gorila();

    Carlos.lanzarAlgo();
    Carlos.lanzarAlgo();
    Carlos.lanzarAlgo();

    Carlos.comerBananas();
    Carlos.comerBananas();

    Carlos.trepar();


}

}
