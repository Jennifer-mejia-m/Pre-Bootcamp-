package GuardianaZoo;

public class MurcielagoTest {

    public static void main(String[] args) {
        
        Murcielago Laura = new Murcielago();

       Laura.atacarPueblos(); 
       Laura.atacarPueblos(); 
       Laura.atacarPueblos(); 

       Laura.comerHumanos();
       Laura.comerHumanos();
       
       Laura.volar();
       Laura.volar();

        
    }
    
}
