package GuardianaZoo;

public class MamiferoTest {
    
    public static void main(String[] args) {


    }

}
